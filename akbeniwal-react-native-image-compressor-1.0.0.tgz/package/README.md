# @akbeniwal/react-native-image-compressor

Simple image compression utility for React Native.

## Install

yarn add @akbeniwal/react-native-image-compressor

## Usage

```ts
import { compressImage } from "@akbeniwal/react-native-image-compressor";

const result = await compressImage(uri, {
  quality: 0.8,
});

console.log(result.uri);
```
